from django.shortcuts import render

# You can now define your Django views here.
