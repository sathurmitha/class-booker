from django.db import models

# You can now define your Django ORM models here if needed.
