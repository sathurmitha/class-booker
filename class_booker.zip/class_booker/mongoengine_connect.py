from mongoengine import connect

def mongo_connect():
    connect(
        db='classbooker',  # Change as needed
        host='localhost',  # Or your MongoDB URI
        port=27017
    )
