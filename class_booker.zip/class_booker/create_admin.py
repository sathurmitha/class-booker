from mongoengine_connect import mongo_connect
mongo_connect()
from ClassBooker.models import Admin
Admin.create_admin("admin", "admin123")
print("Admin user created.")