from django.apps import AppConfig

class ClassBookerConfig(AppConfig):
    name = 'ClassBooker'
