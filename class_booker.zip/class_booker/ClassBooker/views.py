def student_logout(request):
    request.session.flush()
    return redirect('student_login')

from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Course, Student, Enrollment, Admin
from .forms import AdminLoginForm, StudentLoginForm, CourseForm
from bson import ObjectId
from functools import wraps

# Decorators for route protection
def admin_required(view_func):
    @wraps(view_func)
    def _wrapped_view(request, *args, **kwargs):
        if not request.session.get('admin'):
            return redirect('admin_login')
        return view_func(request, *args, **kwargs)
    return _wrapped_view

def student_required(view_func):
    @wraps(view_func)
    def _wrapped_view(request, *args, **kwargs):
        if not request.session.get('student'):
            return redirect('student_login')
        return view_func(request, *args, **kwargs)
    return _wrapped_view

@admin_required
def admin_dashboard(request):
    courses = Course.objects.all()
    return render(request, 'admin_dashboard.html', {'courses': courses})

@admin_required
def admin_logout(request):
    request.session.flush()
    return redirect('admin_login')

@admin_required
def admin_edit_course(request, course_id):
    try:
        course = Course.objects.get(id=ObjectId(course_id))
    except Course.DoesNotExist:
        messages.error(request, 'Course not found.')
        return redirect('admin_dashboard')
    if request.method == 'POST':
        form = CourseForm(request.POST)
        if form.is_valid():
            course.name = form.cleaned_data['name']
            course.total_seats = form.cleaned_data['total_seats']
            course.save()
            messages.success(request, 'Course updated!')
            return redirect('admin_dashboard')
    else:
        form = CourseForm(initial={'name': course.name, 'total_seats': course.total_seats})
    return render(request, 'admin_edit_course.html', {'form': form, 'course': course})

@admin_required
def admin_delete_course(request, course_id):
    try:
        course = Course.objects.get(id=ObjectId(course_id))
    except Course.DoesNotExist:
        messages.error(request, 'Course not found.')
        return redirect('admin_dashboard')
    if request.method == 'POST':
        course.delete()
        messages.success(request, 'Course deleted!')
        return redirect('admin_dashboard')
    return render(request, 'admin_delete_course.html', {'course': course})


def admin_login(request):
    # If already logged in as admin, redirect to admin dashboard
    if request.session.get('admin'):
        return redirect('admin_dashboard')
    jwt_token = None
    if request.method == 'POST':
        form = AdminLoginForm(request.POST)
        if form.is_valid():
            try:
                admin = Admin.objects.get(username=form.cleaned_data['username'])
                if admin.check_password(form.cleaned_data['password']):
                    request.session['admin'] = str(admin.id)
                    jwt_token = admin.generate_jwt()
                    response = redirect('admin_add_course')
                    response.set_cookie('admin_jwt', jwt_token, httponly=True)
                    return response
                else:
                    messages.error(request, 'Invalid credentials')
            except Admin.DoesNotExist:
                messages.error(request, 'Invalid credentials')
    else:
        form = AdminLoginForm()
    return render(request, 'admin_login.html', {'form': form})

@admin_required
def admin_add_course(request):
    if request.method == 'POST':
        form = CourseForm(request.POST)
        if form.is_valid():
            course = Course(
                name=form.cleaned_data['name'],
                total_seats=form.cleaned_data['total_seats'],
                available_seats=form.cleaned_data['total_seats'],
                materials=[]
            )
            # Handle materials
            titles = request.POST.getlist('material_title')
            urls = request.POST.getlist('material_url')
            from .models import CourseMaterial
            for t, u in zip(titles, urls):
                if t and u:
                    course.materials.append(CourseMaterial(title=t, url=u))
            course.save()
            messages.success(request, 'Course added!')
            return redirect('admin_add_course')
    else:
        form = CourseForm()
    return render(request, 'admin_add_course.html', {'form': form})

@student_required
def course_list(request):
    courses = Course.objects.all()
    return render(request, 'course_list.html', {'courses': courses})


def student_login(request):
    # If already logged in, redirect to main page
    if request.session.get('student'):
        return redirect('course_list')
    jwt_token = None
    if request.method == 'POST':
        form = StudentLoginForm(request.POST)
        if form.is_valid():
            try:
                student = Student.objects.get(email=form.cleaned_data['email'])
                if student.check_password(form.cleaned_data['password']):
                    request.session['student'] = str(student.id)
                    jwt_token = student.generate_jwt()
                    response = redirect('course_list')
                    response.set_cookie('student_jwt', jwt_token, httponly=True)
                    return response
                else:
                    messages.error(request, 'Invalid credentials')
            except Student.DoesNotExist:
                messages.error(request, 'Invalid credentials')
    else:
        form = StudentLoginForm()
    return render(request, 'student_login.html', {'form': form})

def student_register(request):
    # If already logged in, redirect to main page
    if request.session.get('student'):
        return redirect('course_list')
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        password = request.POST.get('password')
        if not (name and email and password):
            messages.error(request, 'All fields are required.')
            return render(request, 'student_register.html')
        if Student.objects(email=email).first():
            messages.error(request, 'Email already registered.')
            return render(request, 'student_register.html')
        student = Student.create_student(name=name, email=email, password=password)
        messages.success(request, 'Registration successful. Please log in.')
        return redirect('student_login')
    return render(request, 'student_register.html')

def enroll(request, course_id):
    try:
        course = Course.objects.get(id=ObjectId(course_id))
    except Course.DoesNotExist:
        messages.error(request, 'Course not found.')
        return redirect('course_list')
    if course.available_seats < 1:
        messages.error(request, 'No seats available!')
        return redirect('course_list')
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        password = request.POST.get('password')
        student = Student.objects(email=email).first()
        if not student:
            if not password:
                messages.error(request, 'Password required for new student.')
                return render(request, 'enroll.html', {'course': course})
            student = Student.create_student(name=name, email=email, password=password)
        Enrollment(student=student, course=course).save()
        course.available_seats -= 1
        course.save()
        request.session['student'] = str(student.id)
        jwt_token = student.generate_jwt()
        response = redirect('course_materials', course_id=course.id)
        response.set_cookie('student_jwt', jwt_token, httponly=True)
        return response
    return render(request, 'enroll.html', {'course': course})

@student_required
def course_materials(request, course_id):
    try:
        course = Course.objects.get(id=ObjectId(course_id))
    except Course.DoesNotExist:
        messages.error(request, 'Course not found.')
        return redirect('course_list')
    student_id = request.session.get('student')
    if not student_id or not Enrollment.objects(student=ObjectId(student_id), course=course).first():
        return redirect('enroll', course_id=course.id)
    materials = course.materials
    return render(request, 'course_materials.html', {'course': course, 'materials': materials})
from django.shortcuts import render

# Create your views here.
