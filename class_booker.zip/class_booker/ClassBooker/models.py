from mongoengine import Document, EmbeddedDocument, fields
import datetime
import bcrypt
import jwt
from django.conf import settings

class Admin(Document):
    username = fields.StringField(required=True, unique=True)
    password_hash = fields.StringField(required=True)  # Store hashed password

    @staticmethod
    def create_admin(username, password):
        password_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
        return Admin(username=username, password_hash=password_hash).save()

    def check_password(self, password):
        return bcrypt.checkpw(password.encode(), self.password_hash.encode())

    def generate_jwt(self):
        payload = {'admin_id': str(self.id), 'username': self.username}
        return jwt.encode(payload, settings.SECRET_KEY, algorithm='HS256')

class Student(Document):
    name = fields.StringField(required=True)
    email = fields.EmailField(required=True, unique=True)
    password_hash = fields.StringField(required=True)  # Store hashed password

    @staticmethod
    def create_student(name, email, password):
        password_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
        return Student(name=name, email=email, password_hash=password_hash).save()

    def check_password(self, password):
        return bcrypt.checkpw(password.encode(), self.password_hash.encode())

    def generate_jwt(self):
        payload = {'student_id': str(self.id), 'email': self.email}
        return jwt.encode(payload, settings.SECRET_KEY, algorithm='HS256')

class CourseMaterial(EmbeddedDocument):
    title = fields.StringField(required=True)
    url = fields.URLField(required=True)

class Course(Document):
    name = fields.StringField(required=True, unique=True)
    total_seats = fields.IntField(required=True, min_value=1)
    available_seats = fields.IntField(required=True, min_value=0)
    materials = fields.EmbeddedDocumentListField(CourseMaterial)

class Enrollment(Document):
    student = fields.ReferenceField(Student, required=True)
    course = fields.ReferenceField(Course, required=True)
    enrolled_at = fields.DateTimeField(default=datetime.datetime.utcnow)
