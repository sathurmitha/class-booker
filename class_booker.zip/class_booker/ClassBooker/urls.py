from django.urls import path
from . import views

urlpatterns = [
    path('admin/login/', views.admin_login, name='admin_login'),
    path('admin/add-course/', views.admin_add_course, name='admin_add_course'),
    path('admin/dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('admin/logout/', views.admin_logout, name='admin_logout'),
    path('admin/edit-course/<str:course_id>/', views.admin_edit_course, name='admin_edit_course'),
    path('admin/delete-course/<str:course_id>/', views.admin_delete_course, name='admin_delete_course'),
    path('student/login/', views.student_login, name='student_login'),
    path('student/logout/', views.student_logout, name='student_logout'),
    path('student/register/', views.student_register, name='student_register'),
    path('', views.course_list, name='course_list'),
    path('enroll/<str:course_id>/', views.enroll, name='enroll'),
    path('materials/<str:course_id>/', views.course_materials, name='course_materials'),
]
