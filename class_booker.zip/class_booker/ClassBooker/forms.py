from django import forms

class AdminLoginForm(forms.Form):
    username = forms.CharField(max_length=150)
    password = forms.CharField(widget=forms.PasswordInput)

class StudentLoginForm(forms.Form):
    email = forms.EmailField()
    password = forms.CharField(widget=forms.PasswordInput)

class CourseForm(forms.Form):
    name = forms.CharField(max_length=200)
    total_seats = forms.IntegerField(min_value=1)

class EnrollmentForm(forms.Form):
    name = forms.CharField(max_length=150)
    email = forms.EmailField()
